import os, json

l = []
files = os.listdir('transactions')
for i in files:
    f = open(f"{'transactions'}/{i}")
    l.append(json.loads(f.read()))
blocks = l.copy()
for i in l:
    if i['hash'].startswith('000') and i['hash'].endswith('000'):
        print(f"№1. блок: {i['hash']}", f"номер: {i['index']}", f"автор: {i['transactions'][-1]['to']}",
              sep='\n')
        break
blocks = sorted(blocks, key=lambda x: x['index'])
forks = []
for block in range(len(blocks) - 1):
    if blocks[block]['index'] - blocks[block + 1][f'index'] == 0:
        forks.append(blocks[block])
start_fork = forks[0]
next_fork = None
forks_info = []
for fork in range(len(forks) - 1):
    if forks[fork]['index'] - forks[fork + 1]['index'] != -1:
        forks_info.append((start_fork['index'], forks[fork]['index']))
        start_fork = forks[fork + 1]
else:
    forks_info.append((start_fork['index'], forks[-1]['index']))

len_of_forks = map(lambda x: x[1] - x[0] + 1, forks_info)
len_of_forks = sorted(len_of_forks)
naim = 0
naib = ''
for i in forks_info:
    if (i[1] - i[0] + 1) == 2:
        naim = i[0]
    if i[1] - i[0] + 1 == len_of_forks[-1]:
        naib = i

print("№2. Длина наименьшего форка: ", len_of_forks[0])
print("№3. Номер первого блока в форке наименьшей длины: ", naim)
print("№4. Длина наибольшего форка: ", len_of_forks[-1])
l = []
for i in blocks:
    if naib[0] <= i['index'] <= naib[1]:
        l.append(i)
for_five_info = sorted(forks_info, key=lambda x: x[1] - x[0])
for_five_forks = list(filter(lambda x: for_five_info[-1][0] <= x['index'] <= for_five_info[-1][1], blocks))
max_hash_temp = sorted(for_five_forks, key=lambda x: x['timestamp'])[-1]
print("№5. Хэш последнего блока в отброшенной ветке форка наибольшей длины: ",
      max_hash_temp['pre_hash'])
print("№6. Количество форков: ", len(len_of_forks))
for i in blocks:
    if i['index'] == 71:
        print("№7. Размер вознаграждения за создание блока #71: ", i['transactions'][-1]['value'])

only_indexes = []
for_values = []
dict_values = dict()
for i in blocks:
    if i['index'] not in only_indexes:
        only_indexes.append(i['index'])
        for_values.append(i)

for i in for_values:
    value = i['transactions'][-1]['value']
    if value not in dict_values:
        dict_values[value] = 1
    else:
        dict_values[value] += 1

nums = list(dict_values.values())[2:-1]
print("№8. Период сокращения размера вознаграждения за создание блока (каждые n блоков):", nums[0])

list_for_coef = (list(dict_values.keys())[2:-1])
kd = round(list_for_coef[1] / list_for_coef[0], 2)
val = list_for_coef[-1]
schet = len(list_for_coef)
while (round(val, 2) != round(0.09, 2)):
    val *= kd
    schet += 1

print("№9. Коэффициент сокращения вознаграждения за выработку блока:", kd)
print("№10. № блока, в котором в будущем размер вознаграждения впервые окажется равен 0,09:", schet * 17)

secret_info_list = []
temp_ind = []
temp_secret = []
for i in blocks:
    if len(i['secret_info']) != 0:
        secret_info_list.append(str(i['secret_info']))
        temp_ind.append(i['index'])
print("№11. Блоки, в которых в поле secret_info встречается дополнительная информация: ", *temp_ind)
print("№12. Secret info в порядке её появления: ", " ".join(secret_info_list))
print("№13. Шестнадцатеричная форма представления ключевой строки: ", bytes.fromhex("".join(secret_info_list)).decode('utf-8'))

